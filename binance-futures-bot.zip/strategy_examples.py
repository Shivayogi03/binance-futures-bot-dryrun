def ema_strategy(prices):
    return sum(prices) / len(prices)

def rsi_strategy(prices):
    gains = []
    losses = []
    for i in range(len(prices)-1):
        diff = prices[i+1] - prices[i]
        if diff > 0:
            gains.append(diff)
        else:
            losses.append(abs(diff))
    avg_gain = sum(gains)/len(gains) if gains else 0
    avg_loss = sum(losses)/len(losses) if losses else 1
    rs = avg_gain/avg_loss if avg_loss else 0
    return 100 - (100/(1+rs))
