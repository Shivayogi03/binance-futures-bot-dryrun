BASE_URL = "https://testnet.binancefuture.com"
LOG_PATH = "logs/requests.log"
ERROR_LOG_PATH = "logs/errors.log"
